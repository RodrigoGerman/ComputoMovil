//
//  Disco.swift
//  AgaintsTheCurrent
//
//  Created by Rodrigo German Lopez on 9/20/19.
//  Copyright © 2019 RodrigoGermanLopez. All rights reserved.
//

import UIKit

class DiscoViewController: UIViewController {
    
    var selectedImage: String?
    
    @IBOutlet weak var album: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let imageToLoad = selectedImage{
            album.image = UIImage(named: imageToLoad)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.hidesBarsOnTap = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.hidesBarsOnTap = true
    }

}

