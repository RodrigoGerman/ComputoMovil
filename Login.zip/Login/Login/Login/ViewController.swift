//
//  ViewController.swift
//  Login
//
//  Created by Rodrigo German Lopez on 9/12/19.
//  Copyright © 2019 Rodrigo German Lopez. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var username: UITextField!
    
    @IBOutlet weak var forgotPasswordButton: UIButton!
    
    @IBOutlet weak var forgotUserNameButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "ForgottenUsernameOrPassword"{
            if let sender = sender as? UIButton{
                
                if sender == forgotPasswordButton{
                    segue.destination.navigationItem.title = "Forgot Password"
                }
                    
                else if sender == forgotUserNameButton{
                    segue.destination.navigationItem.title = "Forgot User Name"
                }
            }
        }
        else{
            segue.destination.navigationItem.title = username.text
        }
        
    }
        
    @IBAction func forgotUserName(_ sender: Any) {
        performSegue(withIdentifier: "ForgottenUsernameOrPassword", sender: forgotUserNameButton)
    }
    
    @IBAction func forgotPassword(_ sender: Any) {
        performSegue(withIdentifier: "ForgottenUsernameOrPassword", sender: forgotPasswordButton)
    }
    
}

