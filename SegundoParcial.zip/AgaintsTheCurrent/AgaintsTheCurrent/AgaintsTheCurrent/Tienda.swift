//
//  ViewController.swift
//  AgaintsTheCurrent
//
//  Created by Rodrigo German Lopez on 9/18/19.
//  Copyright © 2019 RodrigoGermanLopez. All rights reserved.
//

import UIKit

class Tienda: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var stepperShirt: UIStepper!
    @IBOutlet weak var stepperBeanie: UIStepper!
    @IBOutlet weak var stepperHoodie: UIStepper!
    @IBOutlet weak var codigoDescuento: UITextField!
    @IBOutlet weak var stepperBag: UIStepper!
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label3: UILabel!
    @IBOutlet weak var label4: UILabel!
    @IBOutlet weak var backgroundScrollView: UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.codigoDescuento.delegate = self;
    }

    @IBAction func pushInfo(_ sender: Any) {
        if let vc = storyboard?.instantiateViewController(withIdentifier: "Información") as? DiscoViewController {
            vc.title = "Información"
            navigationController?.pushViewController(vc, animated: true)
         }
    }
    
    @IBAction func stepperCantidad(_ sender: UIStepper) {
        label1.text = String(Int(sender.value))
    }
    
    @IBAction func stepperCantidad2(_ sender: UIStepper) {
         label2.text = String(Int(sender.value))
    }
    
    @IBAction func stepperCantidad3(_ sender: UIStepper) {
        label3.text = String(Int(sender.value))
    }
    
    @IBAction func stepperCantidad4(_ sender: UIStepper) {
        label4.text = String(Int(sender.value))
    }
    
    @IBAction func pushBuy(_ sender: Any) {
        let codigo = codigoDescuento.text?.uppercased()
        let calculo = (Int(label1.text!)! * 500) + (Int(label2.text!)! * 400) + (Int(label3.text!)! * 1000) + (Int(label4.text!)! * 600)
        if codigo == "ATC2019AJOILK" {
            let descuento =  (Double(calculo) * 0.50)
            let total = Int(Double(calculo) - descuento)
            let compraDescuento = UIAlertController(title: "¡Compra finalizada con cupón de descuento aplicado!\nTotal a pagar: $" + String(total), message: "Gracias por su compra", preferredStyle: UIAlertController.Style.alert)
                compraDescuento.addAction(UIAlertAction(title: "Cerrar", style: UIAlertAction.Style.default, handler: { _ in
                }))
            self.present(compraDescuento, animated: true, completion: nil)
        }else{
            let compraNormal = UIAlertController(title: "¡Compra finalizada!\nTotal a pagar: $" + String(calculo), message: "Gracias por su Compra", preferredStyle: UIAlertController.Style.alert)
                compraNormal.addAction(UIAlertAction(title: "Cerrar", style: UIAlertAction.Style.default, handler: { _ in
                }))
            self.present(compraNormal, animated: true, completion: nil)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
}



