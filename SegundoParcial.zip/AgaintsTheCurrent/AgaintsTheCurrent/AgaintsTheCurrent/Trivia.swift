//
//  ViewController.swift
//  AgaintsTheCurrent
//
//  Created by Rodrigo German Lopez on 9/18/19.
//  Copyright © 2019 RodrigoGermanLopez. All rights reserved.
//

import UIKit

class Trivia: UIViewController {
    
    @IBOutlet weak var switchQuestion1: UISwitch!
    @IBOutlet weak var switchQuestion2: UISwitch!
    @IBOutlet weak var switchQuestion3: UISwitch!
    @IBOutlet weak var switchQuestion4: UISwitch!
    @IBOutlet weak var switchQuestion5: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func pushInfo(_ sender: Any) {
        if let vc = storyboard?.instantiateViewController(withIdentifier: "Información") as? DiscoViewController {
            vc.title = "Información"
            navigationController?.pushViewController(vc, animated: true)
         }
    }
    
    @IBAction func buttonRevisar(_ sender: Any) {
        var conteo = 0
        
        if !switchQuestion1.isOn{
            conteo += 1
        }
        if switchQuestion2.isOn{
            conteo += 1
        }
        if switchQuestion3.isOn{
            conteo += 1
        }
        if !switchQuestion4.isOn{
            conteo += 1
        }
        if !switchQuestion5.isOn{
            conteo += 1
        }
    
        if conteo == 5{
            let win = UIAlertController(title: "¡GANASTE! ¡Felicidades!\nCÓDIGO DE DESCUENTO:\nATC2019AJOILK", message: "\nPreguntas correctas: 5", preferredStyle: UIAlertController.Style.alert)
            win.addAction(UIAlertAction(title: "Cerrar", style: UIAlertAction.Style.default, handler: { _ in
            }))
            self.present(win, animated: true, completion: nil)
            
        }else{
            let loser = UIAlertController(title: "¡PERDISTE!\n¡Intentalo de Nuevo!", message: "Preguntas correctas: " + String(conteo), preferredStyle: UIAlertController.Style.alert)
            loser.addAction(UIAlertAction(title: "Reintentar", style: UIAlertAction.Style.default, handler: { _ in
            }))
            self.present(loser, animated: true, completion: nil)
        }
    }
    
    
}


