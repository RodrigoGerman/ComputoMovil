//
//  Discografia.swift
//  AgaintsTheCurrent
//
//  Created by Rodrigo German Lopez on 9/19/19.
//  Copyright © 2019 RodrigoGermanLopez. All rights reserved.
//

import UIKit

class Discografia: UITableViewController{
    
    var discografia = [String]()
    let albums = ["Infinity","Gravity","In Our Bones","Past Lives"]
    let yearAlbum = ["2014","2015","2016", "2018"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Discografía"
        let fm = FileManager.default
        let path = Bundle.main.resourcePath!
        let items = try! fm.contentsOfDirectory(atPath: path)
        for item in items{
            if item.hasPrefix("Disc"){
                discografia.append(item)
            }
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return discografia.count
    }

    //Asignando tamaño de celda.
    override func tableView(_ tableView: UITableView,
                            heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DiscoCell", for: indexPath)
        cell.imageView?.image = UIImage(named: discografia[indexPath.row])
        //Asignando Discografia.
        let name = discografia[indexPath.row]
        let index = name.index(name.startIndex, offsetBy: 5)
        let index2 = name.index(name.endIndex, offsetBy: -5)
        let pos = Int(name[index...index2]) ?? 0
        cell.textLabel?.text = albums[pos]
        cell.detailTextLabel?.text = yearAlbum[pos]
        return cell
    }
    
    @IBAction func pushInfo(_ sender: Any) {
        if let vc = storyboard?.instantiateViewController(withIdentifier: "Información") as? DiscoViewController {
            vc.title = "Información"
            navigationController?.pushViewController(vc, animated: true)
         }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //Variable momentanea.
        let name = discografia[indexPath.row]
        let index = name.index(name.startIndex, offsetBy: 5)
        let index2 = name.index(name.endIndex, offsetBy: -5)
        let pos = Int(name[index...index2]) ?? 0
        let album = albums[pos]
        
        if let vc = storyboard?.instantiateViewController(withIdentifier: album) as? DiscoViewController {
            vc.title = albums[pos]
            navigationController?.pushViewController(vc, animated: true)
        }
    }
}
