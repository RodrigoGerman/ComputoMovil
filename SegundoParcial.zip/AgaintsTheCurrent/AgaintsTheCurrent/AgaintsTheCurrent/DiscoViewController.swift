//
//  Disco.swift
//  AgaintsTheCurrent
//
//  Created by Rodrigo German Lopez on 9/20/19.
//  Copyright © 2019 RodrigoGermanLopez. All rights reserved.
//

import UIKit

class DiscoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.hidesBarsOnTap = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.hidesBarsOnTap = true
    }

    @IBAction func pushInfo(_ sender: Any) {
        if let vc = storyboard?.instantiateViewController(withIdentifier: "Información") as? DiscoViewController {
            vc.title = "Información"
            navigationController?.pushViewController(vc, animated: true)
         }
    }
}

