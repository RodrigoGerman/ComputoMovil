//
//  ViewController.swift
//  AgaintsTheCurrent
//
//  Created by Rodrigo German Lopez on 9/18/19.
//  Copyright © 2019 RodrigoGermanLopez. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func pushInfo(_ sender: Any) {
        if let vc = storyboard?.instantiateViewController(withIdentifier: "Información") as? DiscoViewController {
            vc.title = "Información"
            navigationController?.pushViewController(vc, animated: true)
         }
    }
    
}

